package cn.hfbin.seckill.redis;

public interface KeyPrefix {
		

	public String getPrefix();
	
}
