# 快快快外卖系统
---
这是一个基于SSM框架（SpringMVC+Spring+MyBatis）的在线订餐外卖系统，基本用户类型有顾客、商家、骑手以及管理员四类
## 系统模块划分
---
*本系统按用户类型划分可分为顾客模块、商家模块、骑手模块和管理员模块；按功能划分可以分为登录模块、注册模块、查询模块、信息维护模块、购物车模块、订单模块、店铺菜单管理模块、配送模块以及评价模块*

![模块图1](https://github.com/TonyWorde/kkkwmxt/blob/master/functionimg/functionimgA.png)

![模块图2](https://github.com/TonyWorde/kkkwmxt/blob/master/functionimg/functionimgB.png)
